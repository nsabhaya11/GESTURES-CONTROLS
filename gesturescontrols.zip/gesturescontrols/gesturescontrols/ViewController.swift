//
//  ViewController.swift
//  gesturescontrols
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
    //tap gestures
        let gest = UITapGestureRecognizer(target: self, action: #selector(self.handle));
        
        img.isUserInteractionEnabled = true;
        
        gest.numberOfTapsRequired = 2;
        
        
        self.view .addGestureRecognizer(gest);
        
        //long press gestures
        let longpress = UILongPressGestureRecognizer(target: self, action: #selector(self.longpressmathord));
        
        longpress.minimumPressDuration = 0.6;
        self.img .addGestureRecognizer(longpress);
// pan gestures
        
        
        let pan = UIPanGestureRecognizer(target: self, action: #selector(self.pangesture));
        
        
        self.img .addGestureRecognizer(pan);
        
        //pinch gestures

        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(self.pinchmathord));
        self.view .addGestureRecognizer(pinch);
        
        //rotaintin gestures
        
        let rotation = UIRotationGestureRecognizer(target: self, action: #selector(self.rotationmathord));
        
        self.view .addGestureRecognizer(rotation);
        //swipe gestures
        
          let left = UISwipeGestureRecognizer(target: self, action: #selector(self.swipmathord));
        
         let right = UISwipeGestureRecognizer(target: self, action: #selector(self.swipmathord));
        
        left.direction = UISwipeGestureRecognizerDirection.left;
        right.direction = UISwipeGestureRecognizerDirection.right;
        
        self.view .addGestureRecognizer(left);
        self.view .addGestureRecognizer(right);
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func swipmathord(sender:UISwipeGestureRecognizer)  {
        
        
        if sender .direction == UISwipeGestureRecognizerDirection.left
        {
            
            img.frame = CGRect(x: self.img.frame.origin.x-100, y: self.img.frame.origin.y, width: self.img.frame.size.width, height: self.img.frame.size.height);
            
        }
        else
        {
            
              img.frame = CGRect(x: self.img.frame.origin.x+100, y: self.img.frame.origin.y, width: self.img.frame.size.width, height: self.img.frame.size.height);
        }
        
    }
    
    func rotationmathord(sender:UIRotationGestureRecognizer) {
        
        img.transform = CGAffineTransform(rotationAngle: sender.rotation);
        
       // sender.rotation = 0.0;
        
        
        
        
    }
    func pinchmathord(sender : UIPinchGestureRecognizer) {
        
        img.transform = CGAffineTransform(scaleX: sender.scale, y: sender.scale);
        
        
        
    }
    
    
    func pangesture(sender: UIPanGestureRecognizer)  {
        
        
        self.img.center = sender.location(in: self.view);
        
        
    }
    func longpressmathord(sender : UILongPressGestureRecognizer) {
        
        if sender.state == UIGestureRecognizerState.ended {
            
            
            print("long press");
        }
        
    }
    func handle(sender :UITapGestureRecognizer)  {
        
        print("ok press");
        
        
    }
    @IBOutlet weak var img: UIImageView!

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

